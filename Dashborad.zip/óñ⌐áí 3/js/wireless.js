class WirelessManager {
    constructor() {
        this.devices = [];
        this.loadDevices();
        this.initForm();
        this.initDevicesList();
        this.startMonitoring();
    }

    initForm() {
        const form = document.getElementById('wirelessForm');
        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addDevice({
                    name: document.getElementById('deviceName').value,
                    type: document.getElementById('deviceType').value,
                    ip: document.getElementById('deviceIP').value,
                    username: document.getElementById('deviceUsername').value,
                    password: document.getElementById('devicePassword').value,
                    port: document.getElementById('devicePort').value || '80',
                    id: Date.now().toString(),
                    status: 'connecting'
                });
            });
        }
    }

    initDevicesList() {
        const container = document.getElementById('devicesList');
        if (!container) return;

        this.renderDevicesList();
    }

    renderDevicesList() {
        const container = document.getElementById('devicesList');
        if (!container) return;

        container.innerHTML = this.devices.map(device => `
            <div class="device-card ${device.status}" data-id="${device.id}">
                <div class="device-header">
                    <div class="device-info">
                        <img src="assets/icons/${this.getDeviceIcon(device.type)}" alt="${device.type}" class="device-icon">
                        <h4>${device.name}</h4>
                    </div>
                    <span class="status-badge ${device.status}">
                        <i class="fas fa-circle"></i>
                        ${this.getStatusText(device.status)}
                    </span>
                </div>
                <div class="device-details">
                    <div class="detail-item">
                        <span>نوع الجهاز:</span>
                        <span>${this.getDeviceName(device.type)}</span>
                    </div>
                    <div class="detail-item">
                        <span>IP:</span>
                        <span>${device.ip}:${device.port}</span>
                    </div>
                    <div class="detail-item">
                        <span>قوة الإشارة:</span>
                        <div class="signal-meter">
                            <div class="signal-bars">
                                <div class="signal-level" style="width: ${device.signalStrength || 0}%"></div>
                            </div>
                            <span class="signal-value">${device.signalStrength || 0}%</span>
                        </div>
                    </div>
                    <div class="detail-item">
                        <span>سرعة الإرسال:</span>
                        <span>${device.txRate || 0} Mbps</span>
                    </div>
                    <div class="detail-item">
                        <span>سرعة الاستقبال:</span>
                        <span>${device.rxRate || 0} Mbps</span>
                    </div>
                    <div class="detail-item">
                        <span>CCQ:</span>
                        <div class="progress-bar">
                            <div class="progress" style="width: ${device.ccq || 0}%"></div>
                            <span>${device.ccq || 0}%</span>
                        </div>
                    </div>
                </div>
                <div class="device-actions">
                    <button class="action-btn refresh" onclick="wirelessManager.refreshDevice('${device.id}')">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                    <button class="action-btn graph" onclick="wirelessManager.showGraph('${device.id}')">
                        <i class="fas fa-chart-line"></i>
                    </button>
                    <button class="action-btn remove" onclick="wirelessManager.removeDevice('${device.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `).join('');
    }

    getDeviceIcon(type) {
        const icons = {
            'mimosa': 'mimosa.png',
            'ubnt': 'ubiquiti.png',
            'default': 'wireless.png'
        };
        return icons[type] || icons.default;
    }

    getDeviceName(type) {
        const names = {
            'mimosa': 'Mimosa',
            'ubnt': 'Ubiquiti'
        };
        return names[type] || type;
    }

    getStatusText(status) {
        const statusMap = {
            'connected': 'متصل',
            'connecting': 'جاري الاتصال',
            'disconnected': 'غير متصل',
            'error': 'خطأ في الاتصال'
        };
        return statusMap[status] || status;
    }

    async addDevice(device) {
        try {
            // التحقق من الاتصال أولاً
            const connectionResult = await this.testConnection(device);
            if (connectionResult.success) {
                this.devices.push({
                    ...device,
                    status: 'connected',
                    signalStrength: 0,
                    txRate: 0,
                    rxRate: 0,
                    ccq: 0
                });
                this.saveDevices();
                this.renderDevicesList();
                this.showSuccess(`تم إضافة الجهاز ${device.name} بنجاح`);
                document.getElementById('wirelessForm').reset();
            } else {
                this.showError(`فشل الاتصال بالجهاز: ${connectionResult.error}`);
            }
        } catch (error) {
            this.showError('حدث خطأ أثناء إضافة الجهاز');
            console.error(error);
        }
    }

    async testConnection(device) {
        try {
            // هنا يجب إضافة كود الاتصال الفعلي بالجهاز حسب نوعه
            const api = this.getDeviceAPI(device);
            return await api.testConnection();
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    getDeviceAPI(device) {
        // إنشاء كائن API مناسب حسب نوع الجهاز
        switch (device.type) {
            case 'mimosa':
                return new MimosaAPI(device);
            case 'ubnt':
                return new UbiquitiAPI(device);
            default:
                return new GenericWirelessAPI(device);
        }
    }

    async refreshDevice(id) {
        const device = this.devices.find(d => d.id === id);
        if (!device) return;

        try {
            const api = this.getDeviceAPI(device);
            const stats = await api.getStats();
            Object.assign(device, stats);
            this.saveDevices();
            this.renderDevicesList();
        } catch (error) {
            console.error(`Error refreshing device ${device.name}:`, error);
            device.status = 'error';
            this.renderDevicesList();
        }
    }

    showGraph(id) {
        const device = this.devices.find(d => d.id === id);
        if (!device) return;
        
        // هنا يمكن إضافة كود لعرض رسم بياني للإحصائيات
        alert('سيتم إضافة الرسوم البيانية قريباً');
    }

    removeDevice(id) {
        if (confirm('هل أنت متأكد من حذف هذا الجهاز؟')) {
            this.devices = this.devices.filter(d => d.id !== id);
            this.saveDevices();
            this.renderDevicesList();
        }
    }

    startMonitoring() {
        // تحديث حالة جميع الأجهزة كل 30 ثانية
        setInterval(() => {
            this.devices.forEach(device => {
                this.refreshDevice(device.id);
            });
        }, 30000);
    }

    saveDevices() {
        localStorage.setItem('wirelessDevices', JSON.stringify(this.devices));
    }

    loadDevices() {
        const saved = localStorage.getItem('wirelessDevices');
        if (saved) {
            this.devices = JSON.parse(saved);
        }
    }

    showSuccess(message) {
        // يمكن استخدام نظام إشعارات أفضل هنا
        alert(message);
    }

    showError(message) {
        // يمكن استخدام نظام إشعارات أفضل هنا
        alert(message);
    }
}

// واجهات برمجة الأجهزة
class GenericWirelessAPI {
    constructor(device) {
        this.device = device;
    }

    async testConnection() {
        // محاكاة اتصال ناجح
        return new Promise(resolve => {
            setTimeout(() => {
                resolve({ success: true });
            }, 1000);
        });
    }

    async getStats() {
        // محاكاة إحصائيات عشوائية
        return new Promise(resolve => {
            setTimeout(() => {
                resolve({
                    status: 'connected',
                    signalStrength: Math.floor(Math.random() * 100),
                    txRate: Math.floor(Math.random() * 300),
                    rxRate: Math.floor(Math.random() * 300),
                    ccq: Math.floor(Math.random() * 100)
                });
            }, 500);
        });
    }
}

class MimosaAPI extends GenericWirelessAPI {
    async getStats() {
        // هنا يمكن إضافة كود خاص بأجهزة Mimosa
        return super.getStats();
    }
}

class UbiquitiAPI extends GenericWirelessAPI {
    async getStats() {
        // هنا يمكن إضافة كود خاص بأجهزة Ubiquiti
        return super.getStats();
    }
}

// تهيئة مدير الأجهزة اللاسلكية عند تحميل الصفحة
window.wirelessManager = new WirelessManager();