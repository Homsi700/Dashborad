class AuthSystem {
    constructor() {
        this.users = [
            { username: 'admin', password: 'admin123', role: 'admin' },
            { username: 'user', password: 'user123', role: 'user' }
        ];
        
        this.initLoginForm();
    }
    
    initLoginForm() {
        const loginForm = document.getElementById('quantumLoginForm');
        
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const username = document.getElementById('starlightUser').value;
            const password = document.getElementById('starlightPass').value;
            
            this.authenticate(username, password);
        });
    }
    
    authenticate(username, password) {
        const user = this.users.find(u => 
            u.username === username && u.password === password
        );
        
        if(user) {
            this.showLoadingAnimation();
            
            setTimeout(() => {
                this.redirectToDashboard(user.role);
            }, 1500);
        } else {
            this.showErrorEffect();
        }
    }
    
    showLoadingAnimation() {
        const btn = document.querySelector('.quantum-button');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري التحقق...';
    }
    
    redirectToDashboard(role) {
        document.getElementById('authPortal').classList.add('animate__fadeOut');
        
        setTimeout(() => {
            document.getElementById('authPortal').style.display = 'none';
            document.getElementById('controlPanel').style.display = 'block';
            document.getElementById('controlPanel').classList.add('animate__fadeIn');
            
            // تغيير نص الترحيب حسب الصلاحية
            const welcomeMsg = document.querySelector('.welcome-message');
            welcomeMsg.textContent = role === 'admin' 
                ? 'مرحباً أيها القائد' 
                : 'مرحباً بك في النظام';
        }, 500);
    }
    
    showErrorEffect() {
        const form = document.getElementById('quantumLoginForm');
        form.classList.add('animate__shakeX');
        
        setTimeout(() => {
            form.classList.remove('animate__shakeX');
        }, 1000);
    }
}

// تهيئة النظام عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new AuthSystem();
});