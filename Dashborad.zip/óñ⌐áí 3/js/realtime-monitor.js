class RealtimeMonitor {
    constructor() {
        this.socket = io('http://localhost:3000');
        this.charts = new Map();
        this.initSocketListeners();
    }

    initSocketListeners() {
        this.socket.on('connect', () => {
            console.log('Connected to monitoring server');
            this.startMonitoring();
        });

        this.socket.on('status-update', (data) => {
            this.updateDashboard(data);
        });

        this.socket.on('monitoring-error', (error) => {
            console.error('Monitoring error:', error);
            this.showError(error.message);
        });
    }

    startMonitoring() {
        const servers = window.mikrotikManager?.getServers() || [];
        servers.forEach(server => {
            this.socket.emit('start-monitoring', server);
        });
    }

    updateDashboard(data) {
        this.updateServerStatus(data.serverStatus);
        this.updateActiveUsers(data.activeUsers);
        this.updateWirelessDevices(data.wirelessDevices);
        this.updateCharts(data);
    }

    updateServerStatus(status) {
        // تحديث حالة السيرفر
        if (status) {
            document.getElementById('cpu-load').textContent = `${status.cpuLoad}%`;
            document.getElementById('memory-usage').textContent = `${status.memoryUsage}%`;
            document.getElementById('uptime').textContent = this.formatUptime(status.uptime);
            document.getElementById('temperature').textContent = status.temperature;

            // تحديث المؤشرات البصرية
            this.updateProgressBar('cpu-progress', status.cpuLoad);
            this.updateProgressBar('memory-progress', status.memoryUsage);
        }
    }

    updateActiveUsers(data) {
        if (!data) return;

        // تحديث إحصائيات المستخدمين
        document.getElementById('total-users').textContent = data.total;
        document.getElementById('active-users').textContent = data.active;

        // تحديث قائمة المستخدمين النشطين
        const activeUsersContainer = document.getElementById('active-users-list');
        if (activeUsersContainer) {
            activeUsersContainer.innerHTML = data.users
                .filter(user => user.status === 'active')
                .map(user => this.createUserCard(user))
                .join('');
        }

        // تحديث قائمة المستخدمين غير النشطين
        const inactiveUsersContainer = document.getElementById('inactive-users-list');
        if (inactiveUsersContainer) {
            inactiveUsersContainer.innerHTML = data.users
                .filter(user => user.status !== 'active')
                .map(user => this.createUserCard(user))
                .join('');
        }
    }

    updateWirelessDevices(devices) {
        if (!devices) return;

        const devicesContainer = document.getElementById('wireless-devices');
        if (devicesContainer) {
            devicesContainer.innerHTML = devices.map(device => `
                <div class="device-card">
                    <div class="device-header">
                        <h3>${device.name}</h3>
                        <span class="badge ${device.clients.length > 0 ? 'online' : 'offline'}">
                            ${device.clients.length} متصل
                        </span>
                    </div>
                    <div class="device-info">
                        <p>SSID: ${device.ssid}</p>
                        <p>التردد: ${device.frequency} MHz</p>
                        <p>النطاق: ${device.band}</p>
                    </div>
                    <div class="clients-list">
                        ${device.clients.map(client => `
                            <div class="client-item">
                                <div class="client-info">
                                    <span>${client.macAddress}</span>
                                    <span class="signal-strength">
                                        ${this.formatSignalStrength(client.signal)}
                                    </span>
                                </div>
                                <div class="client-stats">
                                    <span>TX: ${this.formatSpeed(client.txRate)}</span>
                                    <span>RX: ${this.formatSpeed(client.rxRate)}</span>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `).join('');
        }
    }

    updateCharts(data) {
        // تحديث الرسوم البيانية
        this.updateTrafficChart(data);
        this.updateUsersChart(data);
        this.updateDevicesChart(data);
    }

    createUserCard(user) {
        return `
            <div class="user-card ${user.status}">
                <div class="user-header">
                    <h4>${user.username}</h4>
                    <span class="status-badge ${user.status}">
                        ${this.getStatusText(user.status)}
                    </span>
                </div>
                <div class="user-stats">
                    <div class="stat-item">
                        <span>الباقة:</span>
                        <span>${user.profile}</span>
                    </div>
                    <div class="stat-item">
                        <span>وقت الاتصال:</span>
                        <span>${this.formatUptime(user.uptime)}</span>
                    </div>
                    <div class="stat-item">
                        <span>البيانات المستخدمة:</span>
                        <span>${this.formatBytes(user.bytesIn + user.bytesOut)}</span>
                    </div>
                </div>
            </div>
        `;
    }

    updateProgressBar(id, value) {
        const progressBar = document.getElementById(id);
        if (progressBar) {
            progressBar.style.width = `${value}%`;
            progressBar.className = `progress-bar ${this.getProgressClass(value)}`;
        }
    }

    updateTrafficChart(data) {
        if (!this.charts.has('traffic')) {
            const ctx = document.getElementById('traffic-chart')?.getContext('2d');
            if (ctx) {
                this.charts.set('traffic', new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: [],
                        datasets: [{
                            label: 'إرسال',
                            data: [],
                            borderColor: '#2575fc'
                        }, {
                            label: 'استقبال',
                            data: [],
                            borderColor: '#ff00cc'
                        }]
                    },
                    options: this.getChartOptions('حركة البيانات')
                }));
            }
        }

        const chart = this.charts.get('traffic');
        if (chart) {
            // تحديث البيانات
            const timestamp = new Date(data.timestamp).toLocaleTimeString('ar');
            chart.data.labels.push(timestamp);
            chart.data.datasets[0].data.push(data.serverStatus.txRate);
            chart.data.datasets[1].data.push(data.serverStatus.rxRate);

            // الحفاظ على آخر 20 نقطة فقط
            if (chart.data.labels.length > 20) {
                chart.data.labels.shift();
                chart.data.datasets.forEach(dataset => dataset.data.shift());
            }

            chart.update();
        }
    }

    getChartOptions(title) {
        return {
            responsive: true,
            animation: false,
            plugins: {
                title: {
                    display: true,
                    text: title,
                    font: {
                        family: 'Tajawal',
                        size: 16
                    }
                },
                legend: {
                    position: 'top',
                    labels: {
                        font: {
                            family: 'Tajawal'
                        }
                    }
                }
            },
            scales: {
                x: {
                    ticks: {
                        font: {
                            family: 'Tajawal'
                        }
                    }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        font: {
                            family: 'Tajawal'
                        }
                    }
                }
            }
        };
    }

    formatUptime(uptime) {
        if (!uptime) return '0s';
        const matches = uptime.match(/(\d+)([wdhms])/g);
        if (!matches) return uptime;
        
        return matches.map(match => {
            const value = match.match(/\d+/)[0];
            const unit = match.match(/[wdhms]/)[0];
            const units = {
                'w': 'أسبوع',
                'd': 'يوم',
                'h': 'ساعة',
                'm': 'دقيقة',
                's': 'ثانية'
            };
            return `${value} ${units[unit]}`;
        }).join(' ');
    }

    formatBytes(bytes) {
        const units = ['B', 'KB', 'MB', 'GB', 'TB'];
        let value = bytes;
        let unitIndex = 0;
        
        while (value >= 1024 && unitIndex < units.length - 1) {
            value /= 1024;
            unitIndex++;
        }
        
        return `${value.toFixed(2)} ${units[unitIndex]}`;
    }

    formatSpeed(speed) {
        if (!speed) return '0 Mbps';
        return `${(parseInt(speed) / 1000000).toFixed(2)} Mbps`;
    }

    formatSignalStrength(signal) {
        if (!signal) return 'N/A';
        return `${signal} dBm`;
    }

    getProgressClass(value) {
        if (value >= 90) return 'critical';
        if (value >= 70) return 'warning';
        return 'normal';
    }

    getStatusText(status) {
        const statusMap = {
            'active': 'نشط',
            'inactive': 'غير نشط',
            'disabled': 'معطل',
            'expired': 'منتهي'
        };
        return statusMap[status] || status;
    }

    showError(message) {
        // يمكن استخدام نظام إشعارات أفضل هنا
        console.error(message);
        alert(message);
    }
}

// تهيئة نظام المراقبة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    window.realtimeMonitor = new RealtimeMonitor();
});