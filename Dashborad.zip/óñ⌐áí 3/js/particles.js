// js/particles.js

/**
 * تهيئة نظام الجسيمات الكونية
 * @param {string} elementId - ID عنصر الـ DOM الذي سيحتوي الجسيمات
 */
window.initParticles = function(elementId = 'particles-js') {
    // إعدادات الجسيمات
    const config = {
        particles: {
            number: {
                value: 80,
                density: {
                    enable: true,
                    value_area: 800
                }
            },
            color: {
                value: ["#6a11cb", "#2575fc", "#ff00cc"]
            },
            shape: {
                type: "circle",
                stroke: {
                    width: 0,
                    color: "#000000"
                }
            },
            opacity: {
                value: 0.8,
                random: true,
                anim: {
                    enable: true,
                    speed: 1,
                    opacity_min: 0.1,
                    sync: false
                }
            },
            size: {
                value: 3,
                random: true,
                anim: {
                    enable: true,
                    speed: 2,
                    size_min: 0.1,
                    sync: false
                }
            },
            line_linked: {
                enable: true,
                distance: 150,
                color: "#6a11cb",
                opacity: 0.4,
                width: 1
            },
            move: {
                enable: true,
                speed: 1,
                direction: "none",
                random: true,
                straight: false,
                out_mode: "bounce",
                bounce: true,
                attract: {
                    enable: true,
                    rotateX: 600,
                    rotateY: 1200
                }
            }
        },
        interactivity: {
            detect_on: "canvas",
            events: {
                onhover: {
                    enable: true,
                    mode: "grab"
                },
                onclick: {
                    enable: true,
                    mode: "push"
                },
                resize: true
            },
            modes: {
                grab: {
                    distance: 140,
                    line_linked: {
                        opacity: 1
                    }
                },
                push: {
                    particles_nb: 4
                }
            }
        },
        retina_detect: true
    };

    // تحميل الجسيمات عند اكتمال تحميل الصفحة
    document.addEventListener('DOMContentLoaded', () => {
        particlesJS(elementId, config);
        
        // تكيف مع تغيير حجم النافذة
        window.addEventListener('resize', () => {
            const canvas = document.querySelector(`#${elementId} canvas`);
            if (canvas) {
                canvas.width = window.innerWidth;
                canvas.height = window.innerHeight;
            }
        });
    });
}

// تشغيل الجسيمات تلقائياً عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    initParticles();
});