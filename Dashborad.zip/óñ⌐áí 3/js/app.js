// تهيئة جسيمات الخلفية
function initParticles() {
    const canvas = document.getElementById('particles');
    if (!canvas) return; // التحقق من وجود العنصر أولاً
    
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    const particles = [];
    const colors = ['#ff00cc', '#6a11cb', '#2575fc', '#00ffcc'];
    
    class Particle {
        constructor() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.size = Math.random() * 3 + 1;
            this.color = colors[Math.floor(Math.random() * colors.length)];
            this.speedX = Math.random() * 2 - 1;
            this.speedY = Math.random() * 2 - 1;
        }
        
        update() {
            this.x += this.speedX;
            this.y += this.speedY;
            
            if (this.size > 0.2) this.size -= 0.01;
            if (this.x < 0 || this.x > canvas.width) this.speedX *= -1;
            if (this.y < 0 || this.y > canvas.height) this.speedY *= -1;
        }
        
        draw() {
            ctx.fillStyle = this.color;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fill();
            
            // تأثير التوهج
            ctx.shadowBlur = 10;
            ctx.shadowColor = this.color;
        }
    }
    
    function createParticles() {
        for (let i = 0; i < 80; i++) {
            particles.push(new Particle());
        }
    }
    
    function animateParticles() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        for (let i = 0; i < particles.length; i++) {
            particles[i].update();
            particles[i].draw();
            
            if (particles[i].size <= 0.2) {
                particles.splice(i, 1);
                i--;
                particles.push(new Particle());
            }
        }
        
        requestAnimationFrame(animateParticles);
    }
    
    createParticles();
    animateParticles();
    
    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
}

// تسجيل الدخول
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username')?.value || '';
            const password = document.getElementById('password')?.value || '';
            
            // تحقق بسيط (في الواقع يجب التحقق من السيرفر)
            if (username === 'admin' && password === 'admin123') {
                // تأثير الانتقال
                const authContainer = document.getElementById('authContainer');
                const dashboardContainer = document.getElementById('dashboardContainer');
                
                if (authContainer && dashboardContainer) {
                    authContainer.classList.add('animate__fadeOut');
                    
                    setTimeout(() => {
                        authContainer.style.display = 'none';
                        dashboardContainer.style.display = 'block';
                        dashboardContainer.classList.add('animate__fadeIn');
                        
                        // تهيئة لوحة التحكم
                        initDashboard();
                    }, 500);
                }
            } else {
                alert('بيانات الدخول غير صحيحة!');
            }
        });
    }
    
    // تهيئة باقي المكونات
    initParticles();
});

// تهيئة لوحة التحكم
function initDashboard() {
    const serverChart = document.getElementById('serverChart');
    if (!serverChart) return;
    
    const ctx = serverChart.getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو'],
            datasets: [{
                label: 'حركة البيانات',
                data: [12, 19, 15, 22, 18, 25],
                backgroundColor: 'rgba(106, 17, 203, 0.2)',
                borderColor: 'rgba(106, 17, 203, 1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    rtl: true,
                    labels: {
                        font: {
                            family: 'Tajawal'
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    
    // جعل البطاقات تطفو
    document.querySelectorAll('.card').forEach(card => {
        if (card) {
            card.addEventListener('mouseenter', () => {
                card.style.transform = 'translateY(-10px)';
            });
            card.addEventListener('mouseleave', () => {
                card.style.transform = 'translateY(0)';
            });
        }
    });
}

// دوال إظهار وإخفاء النوافذ المنبثقة
function showModal(modalId) {
    document.getElementById(modalId).style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function showAddServerModal() {
    showModal('addServerModal');
}

function showAddWirelessModal() {
    loadServerList('dishServer');
    showModal('addDishModal');
}

function showAddUserModal() {
    loadServerList('server');
    showModal('addUserModal');
}

// تحميل قائمة السيرفرات في القوائم المنسدلة
function loadServerList(selectId) {
    const select = document.getElementById(selectId);
    select.innerHTML = '<option value="">اختر السيرفر</option>';
    
    // استرجاع قائمة السيرفرات من التخزين المحلي
    const servers = JSON.parse(localStorage.getItem('servers') || '[]');
    
    servers.forEach(server => {
        const option = document.createElement('option');
        option.value = server.ip;
        option.textContent = `${server.name || server.ip}`;
        select.appendChild(option);
    });
}

// معالجة نموذج إضافة سيرفر
document.getElementById('addServerForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const serverData = {
        ip: document.getElementById('serverIp').value,
        username: document.getElementById('serverUsername').value,
        password: document.getElementById('serverPassword').value
    };

    try {
        // إضافة السيرفر إلى التخزين المحلي
        const servers = JSON.parse(localStorage.getItem('servers') || '[]');
        servers.push(serverData);
        localStorage.setItem('servers', JSON.stringify(servers));
        
        // تحديث واجهة المستخدم
        updateServersList();
        
        // إغلاق النافذة المنبثقة
        closeModal('addServerModal');
        
        // تنظيف النموذج
        e.target.reset();
        
        showNotification('تم إضافة السيرفر بنجاح', 'success');
    } catch (error) {
        showNotification('حدث خطأ أثناء إضافة السيرفر', 'error');
        console.error('Error adding server:', error);
    }
});

// معالجة نموذج إضافة طبق
document.getElementById('addDishForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const dishData = {
        name: document.getElementById('dishName').value,
        server: document.getElementById('dishServer').value,
        interface: document.getElementById('dishInterface').value
    };

    try {
        // إضافة الطبق إلى التخزين المحلي
        const dishes = JSON.parse(localStorage.getItem('dishes') || '[]');
        dishes.push(dishData);
        localStorage.setItem('dishes', JSON.stringify(dishes));
        
        // تحديث واجهة المستخدم
        updateWirelessList();
        
        // إغلاق النافذة المنبثقة
        closeModal('addDishModal');
        
        // تنظيف النموذج
        e.target.reset();
        
        showNotification('تم إضافة الطبق بنجاح', 'success');
    } catch (error) {
        showNotification('حدث خطأ أثناء إضافة الطبق', 'error');
        console.error('Error adding dish:', error);
    }
});

// معالجة نموذج إضافة مستخدم
document.getElementById('addUserForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const userData = {
        username: document.getElementById('username').value,
        password: document.getElementById('password').value,
        profile: document.getElementById('profile').value,
        server: document.getElementById('server').value
    };

    try {
        // إضافة المستخدم إلى التخزين المحلي
        const users = JSON.parse(localStorage.getItem('users') || '[]');
        users.push(userData);
        localStorage.setItem('users', JSON.stringify(users));
        
        // تحديث واجهة المستخدم
        updateUsersList();
        
        // إغلاق النافذة المنبثقة
        closeModal('addUserModal');
        
        // تنظيف النموذج
        e.target.reset();
        
        showNotification('تم إضافة المستخدم بنجاح', 'success');
    } catch (error) {
        showNotification('حدث خطأ أثناء إضافة المستخدم', 'error');
        console.error('Error adding user:', error);
    }
});

// وظيفة عرض الإشعارات
function showNotification(message, type = 'info') {
    // يمكنك تخصيص هذه الوظيفة حسب نظام الإشعارات المفضل لديك
    alert(message);
}

// إضافة مستمعي الأحداث لإغلاق النوافذ المنبثقة عند النقر خارجها
document.addEventListener('DOMContentLoaded', () => {
    const modals = document.querySelectorAll('.modal');
    
    modals.forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeModal(modal.id);
            }
        });
    });

    // تحديث حالة البطاقات كل 30 ثانية
    setInterval(updateAllCards, 30000);
});

// تحديث البطاقات
function updateAllCards() {
    updateServers();
    updateWirelessDevices();
    updateUsers();
}

// تحديث قائمة السيرفرات
function updateServers() {
    const serversList = document.getElementById('servers-list');
    if (!serversList) return;

    // سيتم ملؤها بالبيانات من الخادم
    mikrotikManager.getServers().then(servers => {
        serversList.innerHTML = servers.map(server => `
            <div class="item-card server-item">
                <div class="item-header">
                    <h4>${server.name}</h4>
                    <span class="status-badge ${server.status}">
                        <i class="fas fa-circle"></i>
                        ${getStatusText(server.status)}
                    </span>
                </div>
                <div class="item-details">
                    <div class="detail-row">
                        <span>IP:</span>
                        <span>${server.ip}</span>
                    </div>
                    <div class="detail-row">
                        <span>المعالج:</span>
                        <div class="progress-mini">
                            <div class="progress" style="width: ${server.cpu}%"></div>
                        </div>
                    </div>
                    <div class="detail-row">
                        <span>الذاكرة:</span>
                        <div class="progress-mini">
                            <div class="progress" style="width: ${server.memory}%"></div>
                        </div>
                    </div>
                </div>
            </div>
        `).join('');
    });
}

// تحديث قائمة الأطباق اللاسلكية
function updateWirelessDevices() {
    const wirelessList = document.getElementById('wireless-list');
    if (!wirelessList) return;

    // سيتم ملؤها بالبيانات من الخادم
    wirelessManager.getDevices().then(devices => {
        wirelessList.innerHTML = devices.map(device => `
            <div class="item-card wireless-item">
                <div class="item-header">
                    <h4>${device.name}</h4>
                    <span class="status-badge ${device.status}">
                        ${device.clients.length} متصل
                    </span>
                </div>
                <div class="item-details">
                    <div class="detail-row">
                        <span>SSID:</span>
                        <span>${device.ssid}</span>
                    </div>
                    <div class="detail-row">
                        <span>التردد:</span>
                        <span>${device.frequency} MHz</span>
                    </div>
                    <div class="detail-row">
                        <span>القوة:</span>
                        <div class="signal-bar" style="--signal: ${device.signal}%"></div>
                    </div>
                </div>
            </div>
        `).join('');
    });
}

// تحديث قائمة المستخدمين
function updateUsers() {
    const usersList = document.getElementById('users-list');
    if (!usersList) return;

    // سيتم ملؤها بالبيانات من الخادم
    userManager.getUsers().then(users => {
        usersList.innerHTML = users.map(user => `
            <div class="item-card user-item ${user.status}">
                <div class="item-header">
                    <h4>${user.username}</h4>
                    <span class="status-badge ${user.status}">
                        <i class="fas fa-circle"></i>
                        ${getStatusText(user.status)}
                    </span>
                </div>
                <div class="item-details">
                    <div class="detail-row">
                        <span>الباقة:</span>
                        <span>${user.profile}</span>
                    </div>
                    <div class="detail-row">
                        <span>وقت الاتصال:</span>
                        <span>${formatUptime(user.uptime)}</span>
                    </div>
                    <div class="detail-row">
                        <span>البيانات:</span>
                        <span>${formatBytes(user.bytesIn + user.bytesOut)}</span>
                    </div>
                </div>
            </div>
        `).join('');
    });
}

// دوال مساعدة
function getStatusText(status) {
    const statusMap = {
        'connected': 'متصل',
        'disconnected': 'غير متصل',
        'active': 'نشط',
        'inactive': 'غير نشط',
        'disabled': 'معطل'
    };
    return statusMap[status] || status;
}

function formatUptime(uptime) {
    if (!uptime) return '0s';
    const matches = uptime.match(/(\d+)([wdhms])/g);
    if (!matches) return uptime;
    
    return matches.map(match => {
        const value = match.match(/\d+/)[0];
        const unit = match.match(/[wdhms]/)[0];
        const units = {
            'w': 'أسبوع',
            'd': 'يوم',
            'h': 'ساعة',
            'm': 'دقيقة',
            's': 'ثانية'
        };
        return `${value} ${units[unit]}`;
    }).join(' ');
}

function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}