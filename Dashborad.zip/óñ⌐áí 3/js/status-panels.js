class StatusPanels {
    constructor() {
        this.initServerStatus();
        this.initAntennaStatus();
        this.startLiveUpdates();
    }
    
    initServerStatus() {
        const connectionStatus = `
            <span class="status-label">الحالة:</span>
            <span class="status-value online">
                <i class="fas fa-circle"></i> جاري الاتصال...
            </span>
        `;
        
        const signalStrength = `
            <span class="status-label">قوة الإشارة:</span>
            <div class="signal-indicator">
                <div class="signal-bars">
                    <div class="signal-bar"></div>
                    <div class="signal-bar"></div>
                    <div class="signal-bar"></div>
                    <div class="signal-bar"></div>
                </div>
                <span class="signal-value">0%</span>
            </div>
        `;
        
        const dataUsage = `
            <span class="status-label">الاستهلاك:</span>
            <div class="data-usage">
                <div class="usage-bar" style="width: 0%"></div>
                <span class="usage-value">0% من 1TB</span>
            </div>
        `;
        
        document.getElementById('server-connection-status').innerHTML = connectionStatus;
        document.getElementById('server-signal-strength').innerHTML = signalStrength;
        document.getElementById('server-data-usage').innerHTML = dataUsage;
    }
    
    startLiveUpdates() {
        setInterval(() => this.updateStatus(), 3000);
    }
    
    async updateStatus() {
        try {
            const response = await fetch('/api/status');
            const data = await response.json();
            
            this.updateServerStatus(data.server);
            this.updateAntennaStatus(data.antenna);
        } catch (error) {
            console.error('Error fetching status:', error);
        }
    }
    
    updateServerStatus(data) {
        // تحديث حالة السيرفر
    }
    
    updateAntennaStatus(data) {
        // تحديث حالة الطبق
    }
}

// التهيئة التلقائية عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new StatusPanels();

    // إضافة مستمعي الأحداث لأزرار الإضافة
    const addServerBtn = document.getElementById('addServerBtn');
    const addWirelessBtn = document.getElementById('addWirelessBtn');
    const addUserBtn = document.getElementById('addUserBtn');

    if (addServerBtn) {
        addServerBtn.addEventListener('click', () => showModal('addServerModal'));
    }
    if (addWirelessBtn) {
        addWirelessBtn.addEventListener('click', () => showModal('addWirelessModal'));
    }
    if (addUserBtn) {
        addUserBtn.addEventListener('click', () => showModal('addUserModal'));
    }

    // إضافة مستمعي الأحداث لأزرار الإغلاق
    document.querySelectorAll('.modal .close-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const modal = btn.closest('.modal');
            if (modal) {
                hideModal(modal.id);
            }
        });
    });
});