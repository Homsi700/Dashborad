class MikrotikAPI {
    constructor(config) {
        this.config = config;
        this.connected = false;
        this.connection = null;
    }

    async connect() {
        try {
            this.connection = new RouterOSClient({
                host: this.config.ip,
                user: this.config.username,
                password: this.config.password,
                port: parseInt(this.config.port)
            });

            await this.connection.connect();
            this.connected = true;
            return { success: true };
        } catch (error) {
            console.error('خطأ في الاتصال بالسيرفر:', error);
            return { success: false, error: error.message };
        }
    }

    async disconnect() {
        if (this.connection) {
            await this.connection.close();
            this.connected = false;
        }
    }

    async addHotspotUser(userData) {
        try {
            if (!this.connected) {
                await this.connect();
            }

            // إعداد بيانات المستخدم
            const user = {
                name: userData.username,
                password: userData.password,
                profile: userData.profile,
                limit_uptime: `${userData.duration}d`,
                disabled: 'no'
            };

            // إضافة المستخدم إلى السيرفر
            const response = await this.connection.write('/ip/hotspot/user/add', [
                '=name=' + user.name,
                '=password=' + user.password,
                '=profile=' + user.profile,
                '=limit-uptime=' + user.limit_uptime,
                '=disabled=' + user.disabled
            ]);

            return { success: true, data: response };
        } catch (error) {
            console.error('خطأ في إضافة المستخدم:', error);
            return { success: false, error: error.message };
        }
    }

    async removeHotspotUser(username) {
        try {
            if (!this.connected) {
                await this.connect();
            }

            // البحث عن معرف المستخدم
            const users = await this.connection.write('/ip/hotspot/user/print', [
                '?name=' + username
            ]);

            if (users.length > 0) {
                // حذف المستخدم باستخدام المعرف
                await this.connection.write('/ip/hotspot/user/remove', [
                    '=.id=' + users[0]['.id']
                ]);
                return { success: true };
            } else {
                return { success: false, error: 'المستخدم غير موجود' };
            }
        } catch (error) {
            console.error('خطأ في حذف المستخدم:', error);
            return { success: false, error: error.message };
        }
    }

    async updateHotspotUser(username, updates) {
        try {
            if (!this.connected) {
                await this.connect();
            }

            // البحث عن معرف المستخدم
            const users = await this.connection.write('/ip/hotspot/user/print', [
                '?name=' + username
            ]);

            if (users.length > 0) {
                const updateCommands = ['=.id=' + users[0]['.id']];
                
                // إضافة التحديثات المطلوبة
                Object.entries(updates).forEach(([key, value]) => {
                    updateCommands.push(`=${key}=${value}`);
                });

                // تحديث بيانات المستخدم
                await this.connection.write('/ip/hotspot/user/set', updateCommands);
                return { success: true };
            } else {
                return { success: false, error: 'المستخدم غير موجود' };
            }
        } catch (error) {
            console.error('خطأ في تحديث المستخدم:', error);
            return { success: false, error: error.message };
        }
    }

    async getHotspotUsers() {
        try {
            if (!this.connected) {
                await this.connect();
            }

            const users = await this.connection.write('/ip/hotspot/user/print');
            return { success: true, data: users };
        } catch (error) {
            console.error('خطأ في جلب قائمة المستخدمين:', error);
            return { success: false, error: error.message };
        }
    }

    async getUserStatus(username) {
        try {
            if (!this.connected) {
                await this.connect();
            }

            // جلب معلومات المستخدم
            const users = await this.connection.write('/ip/hotspot/user/print', [
                '?name=' + username
            ]);

            if (users.length > 0) {
                // جلب جلسات المستخدم النشطة
                const activeSessions = await this.connection.write('/ip/hotspot/active/print', [
                    '?user=' + username
                ]);

                return {
                    success: true,
                    data: {
                        user: users[0],
                        isActive: activeSessions.length > 0,
                        sessions: activeSessions
                    }
                };
            } else {
                return { success: false, error: 'المستخدم غير موجود' };
            }
        } catch (error) {
            console.error('خطأ في جلب حالة المستخدم:', error);
            return { success: false, error: error.message };
        }
    }
}