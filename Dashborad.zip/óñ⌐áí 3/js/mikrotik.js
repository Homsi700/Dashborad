class MikrotikManager {
    constructor() {
        this.servers = [];
        this.loadServers();
        this.initForm();
        this.initServersList();
        this.startMonitoring();
    }

    initForm() {
        const form = document.getElementById('mikrotikForm');
        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addServer({
                    name: document.getElementById('mtName').value,
                    ip: document.getElementById('mtIP').value,
                    username: document.getElementById('mtUsername').value,
                    password: document.getElementById('mtPassword').value,
                    port: document.getElementById('mtPort').value || '8728',
                    id: Date.now().toString(),
                    status: 'connecting'
                });
            });
        }
    }

    initServersList() {
        const container = document.getElementById('serversList');
        if (!container) return;

        this.renderServersList();
    }

    renderServersList() {
        const container = document.getElementById('serversList');
        if (!container) return;

        container.innerHTML = this.servers.map(server => `
            <div class="server-card ${server.status}" data-id="${server.id}">
                <div class="server-header">
                    <h4>${server.name}</h4>
                    <span class="status-badge ${server.status}">
                        <i class="fas fa-circle"></i>
                        ${this.getStatusText(server.status)}
                    </span>
                </div>
                <div class="server-details">
                    <div class="detail-item">
                        <span>IP:</span>
                        <span>${server.ip}:${server.port}</span>
                    </div>
                    <div class="detail-item">
                        <span>المستخدمين:</span>
                        <span>${server.activeUsers || '0'} / ${server.totalUsers || '0'}</span>
                    </div>
                    <div class="detail-item">
                        <span>استخدام CPU:</span>
                        <div class="progress-bar">
                            <div class="progress" style="width: ${server.cpuLoad || 0}%"></div>
                        </div>
                    </div>
                    <div class="detail-item">
                        <span>الذاكرة:</span>
                        <div class="progress-bar">
                            <div class="progress" style="width: ${server.memoryUsage || 0}%"></div>
                        </div>
                    </div>
                </div>
                <div class="server-actions">
                    <button class="action-btn refresh" onclick="mikrotikManager.refreshServer('${server.id}')">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                    <button class="action-btn remove" onclick="mikrotikManager.removeServer('${server.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `).join('');
    }

    getStatusText(status) {
        const statusMap = {
            'connected': 'متصل',
            'connecting': 'جاري الاتصال',
            'disconnected': 'غير متصل',
            'error': 'خطأ في الاتصال'
        };
        return statusMap[status] || status;
    }

    async addServer(server) {
        try {
            // التحقق من الاتصال أولاً
            const connectionResult = await this.testConnection(server);
            if (connectionResult.success) {
                this.servers.push({
                    ...server,
                    status: 'connected',
                    activeUsers: 0,
                    totalUsers: 0,
                    cpuLoad: 0,
                    memoryUsage: 0
                });
                this.saveServers();
                this.renderServersList();
                this.showSuccess(`تم إضافة السيرفر ${server.name} بنجاح`);
                document.getElementById('mikrotikForm').reset();
            } else {
                this.showError(`فشل الاتصال بالسيرفر: ${connectionResult.error}`);
            }
        } catch (error) {
            this.showError('حدث خطأ أثناء إضافة السيرفر');
            console.error(error);
        }
    }

    async testConnection(server) {
        try {
            // هنا يجب إضافة كود الاتصال الفعلي بسيرفر مايكروتك
            // مثال تجريبي للتوضيح
            return new Promise(resolve => {
                setTimeout(() => {
                    resolve({ 
                        success: true, 
                        error: null 
                    });
                }, 1000);
            });
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    removeServer(id) {
        if (confirm('هل أنت متأكد من حذف هذا السيرفر؟')) {
            this.servers = this.servers.filter(s => s.id !== id);
            this.saveServers();
            this.renderServersList();
        }
    }

    async refreshServer(id) {
        const server = this.servers.find(s => s.id === id);
        if (!server) return;

        try {
            const stats = await this.fetchServerStats(server);
            Object.assign(server, stats);
            this.saveServers();
            this.renderServersList();
        } catch (error) {
            console.error(`Error refreshing server ${server.name}:`, error);
            server.status = 'error';
            this.renderServersList();
        }
    }

    async fetchServerStats(server) {
        // هنا يتم الاتصال الفعلي بالسيرفر وجلب الإحصائيات
        // مثال تجريبي
        return new Promise(resolve => {
            setTimeout(() => {
                resolve({
                    activeUsers: Math.floor(Math.random() * 100),
                    totalUsers: 100,
                    cpuLoad: Math.floor(Math.random() * 100),
                    memoryUsage: Math.floor(Math.random() * 100),
                    status: 'connected'
                });
            }, 500);
        });
    }

    startMonitoring() {
        // تحديث حالة جميع السيرفرات كل 30 ثانية
        setInterval(() => {
            this.servers.forEach(server => {
                this.refreshServer(server.id);
            });
        }, 30000);
    }

    saveServers() {
        localStorage.setItem('mikrotikServers', JSON.stringify(this.servers));
    }

    loadServers() {
        const saved = localStorage.getItem('mikrotikServers');
        if (saved) {
            this.servers = JSON.parse(saved);
        }
    }

    showSuccess(message) {
        // يمكن استخدام نظام إشعارات أفضل هنا
        alert(message);
    }

    showError(message) {
        // يمكن استخدام نظام إشعارات أفضل هنا
        alert(message);
    }
}

// تهيئة مدير مايكروتك عند تحميل الصفحة
window.mikrotikManager = new MikrotikManager();