// js/modules/status-monitor.js

class StatusMonitor {
    constructor() {
        this.initElements();
        this.startRealTimeUpdates();
    }

    initElements() {
        // تهيئة عناصر واجهة المستخدم
        this.elements = {
            serverStatus: {
                txValue: document.getElementById('tx-value'),
                rxValue: document.getElementById('rx-value'),
                uptime: document.getElementById('uptime')
            },
            wirelessDevices: document.getElementById('wirelessDevicesGrid'),
            userStatus: {
                activeUsers: document.getElementById('active-users'),
                totalUsers: document.getElementById('total-users'),
                bandwidth: document.getElementById('bandwidth'),
                usageProgress: document.getElementById('usage-progress')
            }
        };
    }

    startRealTimeUpdates() {
        // تحديث كل 3 ثواني
        this.updateStatus();
        setInterval(() => this.updateStatus(), 3000);
    }

    async updateStatus() {
        try {
            const servers = window.mikrotikManager?.getServers() || [];
            const devices = window.wirelessManager?.getDevices() || [];
            const users = window.userManager?.getUsers() || [];

            await Promise.all([
                this.updateServersStatus(servers),
                this.updateWirelessDevices(devices),
                this.updateUsersStatus(users)
            ]);
        } catch (error) {
            console.error('خطأ في تحديث البيانات:', error);
            this.showErrorState();
        }
    }

    async updateServersStatus(servers) {
        servers.forEach(server => {
            this.updateServerStats(server);
        });
    }

    async updateWirelessDevices(devices) {
        if (!this.elements.wirelessDevices) return;

        // تحديث حالة كل طبق لاسلكي
        this.elements.wirelessDevices.innerHTML = devices.map(device => `
            <div class="wireless-mini-card ${device.status}">
                <div class="wireless-mini-header">
                    <img src="assets/icons/${this.getDeviceIcon(device.type)}" 
                         alt="${device.type}" 
                         class="device-icon" 
                         style="width: 20px; height: 20px;">
                    <h5>${device.name}</h5>
                    <span class="status-badge ${device.status}">
                        <i class="fas fa-circle"></i>
                    </span>
                </div>
                <div class="wireless-mini-stats">
                    <div class="stat-row">
                        <span>الإشارة:</span>
                        <div class="signal-mini-meter">
                            <div class="signal-mini-level" 
                                 style="width: ${device.signalStrength || 0}%"></div>
                        </div>
                    </div>
                    <div class="stat-row">
                        <span>TX/RX:</span>
                        <span>${device.txRate || 0}/${device.rxRate || 0} Mbps</span>
                    </div>
                    <div class="stat-row">
                        <span>CCQ:</span>
                        <span>${device.ccq || 0}%</span>
                    </div>
                </div>
            </div>
        `).join('');
    }

    getDeviceIcon(type) {
        const icons = {
            'mimosa': 'mimosa.png',
            'ubnt': 'ubiquiti.png',
            'default': 'wireless.png'
        };
        return icons[type] || icons.default;
    }

    async updateUsersStatus(users) {
        users.forEach(user => {
            this.updateUserStats(user);
        });
    }

    updateServerStats(data) {
        if (this.elements.serverStatus.txValue) {
            this.elements.serverStatus.txValue.textContent = data.tx;
        }
        if (this.elements.serverStatus.rxValue) {
            this.elements.serverStatus.rxValue.textContent = data.rx;
        }
        if (this.elements.serverStatus.uptime) {
            this.elements.serverStatus.uptime.textContent = data.uptime;
        }
    }

    updateUserStats(data) {
        if (this.elements.userStatus.activeUsers) {
            this.elements.userStatus.activeUsers.textContent = data.activeUsers;
        }
        if (this.elements.userStatus.totalUsers) {
            this.elements.userStatus.totalUsers.textContent = data.totalUsers;
        }
        if (this.elements.userStatus.bandwidth) {
            this.elements.userStatus.bandwidth.textContent = `${data.bandwidth} Mbps`;
        }
        if (this.elements.userStatus.usageProgress) {
            this.elements.userStatus.usageProgress.style.width = `${data.usagePercentage}%`;
            this.setUsageClass(data.usagePercentage);
        }
    }

    setSignalClass(strength) {
        const level = this.elements.wirelessStatus?.signalLevel;
        if (!level) return;
        
        level.className = 'signal-level';
        if (strength >= 80) level.classList.add('excellent');
        else if (strength >= 60) level.classList.add('good');
        else if (strength >= 40) level.classList.add('fair');
        else level.classList.add('poor');
    }

    setUsageClass(percentage) {
        const progress = this.elements.userStatus.usageProgress;
        if (!progress) return;
        
        progress.className = 'usage-progress';
        if (percentage >= 90) progress.classList.add('critical');
        else if (percentage >= 70) progress.classList.add('high');
        else progress.classList.add('normal');
    }

    formatUptime(days) {
        const hours = this.randomValue(0, 23);
        return `${days}d ${hours}h`;
    }

    randomValue(min, max) {
        return Math.floor(Math.random() * (max - min + 1) + min);
    }

    showErrorState() {
        if (this.elements.wirelessDevices) {
            this.elements.wirelessDevices.innerHTML = `
                <div class="error-msg">
                    <i class="fas fa-exclamation-triangle"></i>
                    لا يمكن تحديث بيانات الأطباق حالياً
                </div>
            `;
        }

        Object.values(this.elements).forEach(category => {
            if (category instanceof HTMLElement) {
                category.textContent = '--';
            } else {
                Object.values(category).forEach(element => {
                    if (element) {
                        element.textContent = '--';
                    }
                });
            }
        });
    }
}

// تهيئة نظام المراقبة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    new StatusMonitor();
});