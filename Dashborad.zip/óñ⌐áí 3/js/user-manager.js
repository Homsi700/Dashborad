class UserManager {
    constructor() {
        this.users = [];
        this.selectedServerId = null; // سيتم تحديده لاحقاً
        this.initForm();
        this.loadFromLocalStorage();
        this.initServerSelector();
    }

    initServerSelector() {
        const selector = document.getElementById('serverSelector');
        if (selector) {
            // جلب قائمة السيرفرات من مدير مايكروتك
            const servers = window.mikrotikManager?.getServers() || [];
            
            selector.innerHTML = `
                <option value="">اختر السيرفر</option>
                ${servers.map(server => `
                    <option value="${server.id}">${server.name} (${server.ip})</option>
                `).join('')}
            `;

            selector.addEventListener('change', (e) => {
                this.selectedServerId = e.target.value;
            });
        }
    }

    initForm() {
        const form = document.getElementById('broadbandUserForm');
        if (form) {
            form.addEventListener('submit', async (e) => {
                e.preventDefault();
                
                if (!this.selectedServerId) {
                    this.showError('الرجاء اختيار السيرفر أولاً');
                    return;
                }

                const userData = {
                    username: document.getElementById('username').value,
                    password: document.getElementById('password').value,
                    profile: document.getElementById('speedProfile').value,
                    duration: parseInt(document.getElementById('duration').value),
                    serverId: this.selectedServerId,
                    createdAt: new Date().toISOString(),
                    expiresAt: this.calculateExpiryDate(parseInt(document.getElementById('duration').value))
                };

                await this.addUser(userData);
            });
        }
    }

    calculateExpiryDate(days) {
        const date = new Date();
        date.setDate(date.getDate() + days);
        return date.toISOString();
    }

    async addUser(userData) {
        try {
            // التحقق من عدم تكرار اسم المستخدم
            if (this.users.some(u => u.username === userData.username)) {
                this.showError('اسم المستخدم موجود مسبقاً');
                return;
            }

            // إضافة المستخدم إلى سيرفر مايكروتك
            const server = window.mikrotikManager?.getServerById(userData.serverId);
            if (!server) {
                this.showError('السيرفر غير موجود');
                return;
            }

            const result = await this.addUserToMikrotik(userData, server);
            if (result.success) {
                this.users.push({
                    ...userData,
                    id: Date.now().toString(),
                    status: 'active'
                });

                this.saveToLocalStorage();
                this.renderUsersList();
                this.showSuccess(`تم إضافة المستخدم ${userData.username} بنجاح`);
                document.getElementById('broadbandUserForm').reset();
            } else {
                this.showError(`فشل إضافة المستخدم: ${result.error}`);
            }
        } catch (error) {
            console.error('Error adding user:', error);
            this.showError('حدث خطأ أثناء إضافة المستخدم');
        }
    }

    async addUserToMikrotik(userData, server) {
        try {
            const api = new MikrotikAPI({
                ip: server.ip,
                username: server.username,
                password: server.password,
                port: server.port
            });

            const result = await api.addHotspotUser(userData);
            await api.disconnect();
            return result;
        } catch (error) {
            console.error('خطأ في إضافة المستخدم:', error);
            return { success: false, error: error.message };
        }
    }

    renderUsersList() {
        const container = document.getElementById('usersList');
        if (!container) return;

        container.innerHTML = this.users.map(user => `
            <div class="user-card ${user.status}" data-id="${user.id}">
                <div class="user-header">
                    <div class="user-info">
                        <i class="fas fa-user-astronaut"></i>
                        <h4>${user.username}</h4>
                    </div>
                    <span class="status-badge ${user.status}">
                        <i class="fas fa-circle"></i>
                        ${this.getStatusText(user.status)}
                    </span>
                </div>
                <div class="user-details">
                    <div class="detail-item">
                        <span>السرعة:</span>
                        <span>${user.profile}</span>
                    </div>
                    <div class="detail-item">
                        <span>تاريخ الإنشاء:</span>
                        <span>${new Date(user.createdAt).toLocaleDateString('ar')}</span>
                    </div>
                    <div class="detail-item">
                        <span>تاريخ الانتهاء:</span>
                        <span>${new Date(user.expiresAt).toLocaleDateString('ar')}</span>
                    </div>
                    <div class="detail-item">
                        <span>السيرفر:</span>
                        <span>${this.getServerName(user.serverId)}</span>
                    </div>
                </div>
                <div class="user-actions">
                    <button class="action-btn refresh" onclick="userManager.refreshUser('${user.id}')">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                    <button class="action-btn disable" onclick="userManager.toggleUser('${user.id}')">
                        <i class="fas fa-power-off"></i>
                    </button>
                    <button class="action-btn remove" onclick="userManager.removeUser('${user.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `).join('');
    }

    getServerName(serverId) {
        const server = window.mikrotikManager?.getServerById(serverId);
        return server ? server.name : 'غير معروف';
    }

    getStatusText(status) {
        const statusMap = {
            'active': 'نشط',
            'disabled': 'معطل',
            'expired': 'منتهي'
        };
        return statusMap[status] || status;
    }

    async toggleUser(id) {
        const user = this.users.find(u => u.id === id);
        if (!user) return;

        try {
            const server = window.mikrotikManager?.getServerById(user.serverId);
            if (!server) {
                this.showError('السيرفر غير موجود');
                return;
            }

            const newStatus = user.status === 'active' ? 'disabled' : 'active';
            // تحديث حالة المستخدم في السيرفر
            const result = await this.updateUserInMikrotik(user, server, newStatus);
            
            if (result.success) {
                user.status = newStatus;
                this.saveToLocalStorage();
                this.renderUsersList();
                this.showSuccess(`تم ${newStatus === 'active' ? 'تفعيل' : 'تعطيل'} المستخدم بنجاح`);
            } else {
                this.showError(`فشل تحديث حالة المستخدم: ${result.error}`);
            }
        } catch (error) {
            console.error('Error toggling user:', error);
            this.showError('حدث خطأ أثناء تحديث حالة المستخدم');
        }
    }

    async removeUser(id) {
        if (!confirm('هل أنت متأكد من حذف هذا المستخدم؟')) return;

        const user = this.users.find(u => u.id === id);
        if (!user) return;

        try {
            const server = window.mikrotikManager?.getServerById(user.serverId);
            if (!server) {
                this.showError('السيرفر غير موجود');
                return;
            }

            // حذف المستخدم من السيرفر
            const result = await this.removeUserFromMikrotik(user, server);
            
            if (result.success) {
                this.users = this.users.filter(u => u.id !== id);
                this.saveToLocalStorage();
                this.renderUsersList();
                this.showSuccess('تم حذف المستخدم بنجاح');
            } else {
                this.showError(`فشل حذف المستخدم: ${result.error}`);
            }
        } catch (error) {
            console.error('Error removing user:', error);
            this.showError('حدث خطأ أثناء حذف المستخدم');
        }
    }

    async updateUserInMikrotik(user, server, newStatus) {
        try {
            const api = new MikrotikAPI({
                ip: server.ip,
                username: server.username,
                password: server.password,
                port: server.port
            });

            const result = await api.updateHotspotUser(user.username, {
                disabled: newStatus === 'disabled' ? 'yes' : 'no'
            });
            await api.disconnect();
            return result;
        } catch (error) {
            console.error('خطأ في تحديث المستخدم:', error);
            return { success: false, error: error.message };
        }
    }

    async removeUserFromMikrotik(user, server) {
        try {
            const api = new MikrotikAPI({
                ip: server.ip,
                username: server.username,
                password: server.password,
                port: server.port
            });

            const result = await api.removeHotspotUser(user.username);
            await api.disconnect();
            return result;
        } catch (error) {
            console.error('خطأ في حذف المستخدم:', error);
            return { success: false, error: error.message };
        }
    }

    saveToLocalStorage() {
        localStorage.setItem('broadbandUsers', JSON.stringify(this.users));
    }

    loadFromLocalStorage() {
        const saved = localStorage.getItem('broadbandUsers');
        if (saved) {
            this.users = JSON.parse(saved);
        }
    }

    showSuccess(message) {
        // يمكن استخدام نظام إشعارات أفضل هنا
        alert(message);
    }

    showError(message) {
        // يمكن استخدام نظام إشعارات أفضل هنا
        alert(message);
    }
}

// تهيئة مدير المستخدمين عند تحميل الصفحة
window.userManager = new UserManager();