const express = require('express');
const cors = require('cors');
const { RouterOSClient } = require('node-routeros');
const { createServer } = require('http');
const { Server } = require('socket.io');

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

const port = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('.'));

// تخزين اتصالات API
const connections = new Map();

// دالة إنشاء اتصال جديد
async function getConnection(serverConfig) {
    const key = `${serverConfig.ip}:${serverConfig.port}`;
    if (!connections.has(key)) {
        const client = new RouterOSClient({
            host: serverConfig.ip,
            user: serverConfig.username,
            password: serverConfig.password,
            port: parseInt(serverConfig.port)
        });
        await client.connect();
        connections.set(key, client);
    }
    return connections.get(key);
}

// نظام مراقبة الوقت الحقيقي
class RealTimeMonitor {
    constructor(io) {
        this.io = io;
        this.monitoringIntervals = new Map();
    }

    async startMonitoring(server) {
        const key = `${server.ip}:${server.port}`;
        if (this.monitoringIntervals.has(key)) return;

        const interval = setInterval(async () => {
            try {
                const client = await getConnection(server);
                
                // جمع البيانات من السيرفر
                const [
                    serverStatus,
                    activeUsers,
                    wirelessDevices
                ] = await Promise.all([
                    this.getServerStatus(client),
                    this.getActiveUsers(client),
                    this.getWirelessDevices(client)
                ]);

                // إرسال التحديثات للمتصفح
                this.io.emit('status-update', {
                    serverId: server.id,
                    serverStatus,
                    activeUsers,
                    wirelessDevices,
                    timestamp: new Date().toISOString()
                });
            } catch (error) {
                console.error(`Error monitoring server ${server.ip}:`, error);
                this.io.emit('monitoring-error', {
                    serverId: server.id,
                    error: error.message
                });
            }
        }, 3000); // تحديث كل 3 ثواني

        this.monitoringIntervals.set(key, interval);
    }

    async getServerStatus(client) {
        const resources = await client.write('/system/resource/print');
        const health = await client.write('/system/health/print');
        
        return {
            cpuLoad: resources[0]['cpu-load'],
            memoryUsage: Math.round((resources[0]['total-memory'] - resources[0]['free-memory']) / resources[0]['total-memory'] * 100),
            uptime: resources[0].uptime,
            temperature: health[0]?.temperature || 'N/A'
        };
    }

    async getActiveUsers(client) {
        const [allUsers, activeUsers] = await Promise.all([
            client.write('/ip/hotspot/user/print'),
            client.write('/ip/hotspot/active/print')
        ]);

        const activeMap = new Map(activeUsers.map(u => [u.user, u]));

        return {
            total: allUsers.length,
            active: activeUsers.length,
            users: allUsers.map(user => ({
                username: user.name,
                profile: user.profile,
                uptime: activeMap.get(user.name)?.uptime || '0s',
                bytesIn: activeMap.get(user.name)?.['bytes-in'] || 0,
                bytesOut: activeMap.get(user.name)?.['bytes-out'] || 0,
                status: activeMap.has(user.name) ? 'active' : user.disabled === 'true' ? 'disabled' : 'inactive'
            }))
        };
    }

    async getWirelessDevices(client) {
        const interfaces = await client.write('/interface/wireless/print');
        const registration = await client.write('/interface/wireless/registration-table/print');

        return interfaces.map(iface => ({
            name: iface.name,
            macAddress: iface['mac-address'],
            ssid: iface.ssid,
            frequency: iface.frequency,
            band: iface.band,
            clients: registration.filter(r => r.interface === iface.name).map(client => ({
                macAddress: client['mac-address'],
                signal: client['signal-strength'],
                txRate: client['tx-rate'],
                rxRate: client['rx-rate'],
                uptime: client.uptime
            }))
        }));
    }

    stopMonitoring(server) {
        const key = `${server.ip}:${server.port}`;
        const interval = this.monitoringIntervals.get(key);
        if (interval) {
            clearInterval(interval);
            this.monitoringIntervals.delete(key);
        }
    }
}

const monitor = new RealTimeMonitor(io);

// Socket.IO إدارة الاتصالات
io.on('connection', (socket) => {
    console.log('Client connected');

    socket.on('start-monitoring', async (server) => {
        try {
            await monitor.startMonitoring(server);
            socket.emit('monitoring-started', { serverId: server.id });
        } catch (error) {
            socket.emit('monitoring-error', {
                serverId: server.id,
                error: error.message
            });
        }
    });

    socket.on('stop-monitoring', (server) => {
        monitor.stopMonitoring(server);
        socket.emit('monitoring-stopped', { serverId: server.id });
    });

    socket.on('disconnect', () => {
        console.log('Client disconnected');
    });
});

// إضافة مستخدم جديد
app.post('/api/hotspot/users', async (req, res) => {
    try {
        const { server, userData } = req.body;
        const client = await getConnection(server);
        
        const response = await client.write('/ip/hotspot/user/add', [
            '=name=' + userData.username,
            '=password=' + userData.password,
            '=profile=' + userData.profile,
            '=limit-uptime=' + userData.duration + 'd',
            '=disabled=no'
        ]);
        
        res.json({ success: true, data: response });
    } catch (error) {
        console.error('Error adding user:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// حذف مستخدم
app.delete('/api/hotspot/users/:username', async (req, res) => {
    try {
        const { server } = req.body;
        const { username } = req.params;
        const client = await getConnection(server);
        
        const users = await client.write('/ip/hotspot/user/print', [
            '?name=' + username
        ]);
        
        if (users.length > 0) {
            await client.write('/ip/hotspot/user/remove', [
                '=.id=' + users[0]['.id']
            ]);
            res.json({ success: true });
        } else {
            res.status(404).json({ success: false, error: 'المستخدم غير موجود' });
        }
    } catch (error) {
        console.error('Error removing user:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// تحديث حالة مستخدم
app.put('/api/hotspot/users/:username', async (req, res) => {
    try {
        const { server, updates } = req.body;
        const { username } = req.params;
        const client = await getConnection(server);
        
        const users = await client.write('/ip/hotspot/user/print', [
            '?name=' + username
        ]);
        
        if (users.length > 0) {
            const updateCommands = ['=.id=' + users[0]['.id']];
            Object.entries(updates).forEach(([key, value]) => {
                updateCommands.push(`=${key}=${value}`);
            });
            
            await client.write('/ip/hotspot/user/set', updateCommands);
            res.json({ success: true });
        } else {
            res.status(404).json({ success: false, error: 'المستخدم غير موجود' });
        }
    } catch (error) {
        console.error('Error updating user:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// جلب قائمة المستخدمين
app.get('/api/hotspot/users', async (req, res) => {
    try {
        const { server } = req.query;
        const client = await getConnection(JSON.parse(server));
        
        const users = await client.write('/ip/hotspot/user/print');
        res.json({ success: true, data: users });
    } catch (error) {
        console.error('Error getting users:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// معالجة إغلاق التطبيق
process.on('SIGINT', async () => {
    for (const [key, client] of connections) {
        try {
            await client.close();
        } catch (error) {
            console.error(`Error closing connection to ${key}:`, error);
        }
    }
    process.exit(0);
});

httpServer.listen(port, () => {
    console.log(`Server running on port ${port}`);
});